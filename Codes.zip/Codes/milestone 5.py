
#Flights Year:
# Use groupby to get a count by date.
summary_sdf = sdf.where(col("Year") > 2018).groupby("Year").count().sort("Year")
df = summary_sdf.toPandas()
# Create a bar plot
myplot = df.plot.bar('Year','count')
# Set the x-axis and y-axis labels
myplot.set(xlabel='Date', ylabel='Number of Fligths')
# Set the title
myplot.set(title='Number of Flights by Year')
myplot.figure.set_tight_layout('tight')

#Flights Month:
# Use groupby to get a count by month.
summary_sdf = sdf.groupby("Month").count().sort("Month")
df = summary_sdf.toPandas()
# Create a bar plot
myplot = df.plot.bar('Month','count')
# Set the x-axis and y-axis labels
myplot.set(xlabel='Month', ylabel='Number of Flights')
# Set the title
myplot.set(title='Number of Flights by Month')
myplot.figure.set_tight_layout('tight')

#Flights Week:
# Groupby to get a count by day of the week.
summary_sdf = sdf.groupby("DayOfWeek").count().sort("DayOfWeek")
df = summary_sdf.toPandas()
# Create bar plot
myplot = df.plot.bar('DayOfWeek','count')
# Set the x-axis and y-axis labels
myplot.set(xlabel='Day of the Week', ylabel='Number of Flights')
# Set the title
myplot.set(title='Number of Flights by Day of the Week')
myplot.figure.set_tight_layout('tight')

#Flights Airline:
# Show frequency of the 'airline' column
airline_counts_df = sdf.groupby('Airline').count().sort('Airline').toPandas()
# Set Matplotlib figure
fig = plt.figure(facecolor='white')
# Bar Plot of airline and count
plt.bar(airline_counts_df['Airline'],airline_counts_df['count'] )
# Rotate x-axis labels
plt.xticks(rotation=90)
# Adda title
plt.title("Count by Airline")

#Flight Delays:
# Import necessary libraries
import matplotlib.pyplot as plt
# Plot a histogram
plt.hist(sdf.select('DepDelayMinutes').rdd.flatMap(lambda x: x).collect(), bins=30)
plt.xlabel('DepDelayMinutes')
plt.ylabel('Frequency')
plt.title('Distribution of DepDelayMinutes')
plt.show()

#Correlation Matrix:
# Import necessary libraries
import seaborn as sns
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.stat import Correlation
import matplotlib.pyplot as plt
import pandas as pd
# Convert the numeric values to vector columns
vector_column = "correlation_features"
# Choose the numeric (Double) columns
numeric_columns = ['CRSDepTime', 'DepTime', 'DepDelay', 'DepDelayMinutes', 'ArrTime', 'ArrDelay', 'Year', 'Quarter', 'Month', 'DayofMonth', 'DayOfWeek', 'CRSArrTime', 'ArrDelayMinutes']
assembler = VectorAssembler(inputCols=numeric_columns, outputCol=vector_column)
sdf_vector = assembler.transform(sdf).select(vector_column)
# Create the correlation matrix, then to a list
matrix = Correlation.corr(sdf_vector, vector_column).collect()[0][0]
correlation_matrix = matrix.toArray().tolist()
# Convert the correlation to a Pandas dataframe
correlation_matrix_df = pd.DataFrame(data=correlation_matrix, columns=numeric_columns, index=numeric_columns)
# Plotting the heatmap
heatmap_plot = plt.figure(figsize=(16,5))
# Plot using Seaborn
sns.set_style("white")
sns.heatmap(correlation_matrix_df,
            xticklabels=correlation_matrix_df.columns.values,
            yticklabels=correlation_matrix_df.columns.values,  cmap="Greens", annot=True)
