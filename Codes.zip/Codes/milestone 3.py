# Import needed libraries
import pyarrow
import fastparquet
import pandas as pd

# EDA function
def perform_EDA(df: pd.DataFrame, filename: str):
    # Print number of observations
    print(f"{filename} Number of observations: {len(df)}")

    # Print total number of columns
    print(f"{filename} Total number of columns: {len(df.columns)}")

    # Print list of variables
    print(f"{filename} List of variables:")
    print(list(df.columns))

    # Print total missing fields in the observations
    print(f"{filename} Number of missing fields in the observations:")
    print(df.isnull().sum())

    # Print stats for df
    print(f"{filename} Summary statistics for numeric variables:")
    print(df.describe().loc[['min', 'max', 'mean', 'std']])

    # Print shape of df
    print(f"{filename} Shape:")
    print(df.shape)

    # Print info about df
    print(f"{filename} Info:")
    print(df.info())

# Define path and read file
filepath = "gs://your-project-bucket-name/cleaned/cleaned_flights.parquet"
df = pd.read_parquet(filepath, engine='pyarrow')

# Perform EDA
perform_EDA(df, "cleaned_flights.parquet")

# Import needed libraries
import pandas as pd

# Choose relevant columns
columns_to_keep = ['FlightDate','Airline', 'Origin', 'Cancelled', 'Diverted', 'CRSDepTime',
                   'DepTime', 'DepDelay', 'DepDelayMinutes', 'ArrTime', 'ArrDelay',
                   'Year', 'Quarter', 'Month', 'DayofMonth', 'DayOfWeek',
                   'CRSArrTime', 'ArrDelayMinutes']

# Create new df
cleaned_df = flights_df[columns_to_keep].copy()
