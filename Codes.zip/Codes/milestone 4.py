
# Import needed libraries
import pandas as pd
from pyspark.sql.functions import col, isnan, when, count, udf, to_date, year, month, date_format, size, split
from pyspark.ml.feature import VectorAssembler, StringIndexer, OneHotEncoder
from pyspark.ml import Pipeline
from pyspark.ml.classification import LogisticRegression
from pyspark.ml.evaluation import *
from pyspark.ml.tuning import *

# Set up the path to cleaned data stored on GCS
bucket = ''
filename = 'cleaned_flights.parquet'
file_path = 'gs://' + bucket + filename
sdf = spark.read.parquet(file_path)
sdf.printSchema()

# Get the number of records
sdf.count()

# Look at statistics for some specific columns
sdf.select("DepDelayMinutes", "Year", "ArrDelayMinutes").summary("count", "min", "max", "mean").show()

#Get smaller sample
sdf = sdf.sample(False, 0.2)

# Define the pipeline stages
indexer = StringIndexer(inputCols=["Airline", "Origin"], outputCols=["AirlineIndex", "OriginIndex"])
encoder = OneHotEncoder(inputCols=["AirlineIndex", "OriginIndex"], outputCols=["AirlineVector", "OriginVector"])
assembler = VectorAssembler(inputCols=["AirlineVector", "OriginVector", "CRSDepTime", "DepTime", "DepDelay", "DepDelayMinutes",
                                       "ArrTime", "ArrDelay", "Year", "Quarter", "Month", "DayofMonth", "DayOfWeek",
                                       "CRSArrTime", "ArrDelayMinutes"], outputCol="features")

# Define the pipeline
pipeline = Pipeline(stages=[indexer, encoder, assembler])

# Fit the pipeline to DataFrame and transform it
transformed_sdf = pipeline.fit(sdf).transform(sdf)

# Show the transformed DataFrame
transformed_sdf.select('Airline', 'Origin', 'CRSDepTime', 'DepTime', 'DepDelay', 'DepDelayMinutes',
                       'ArrTime', 'ArrDelay', 'Year', 'Quarter', 'Month', 'DayofMonth', 'DayOfWeek',
                       'CRSArrTime', 'ArrDelayMinutes', 'features').show(20, truncate=False)


# Split the data into 70% training and 30% test sets
trainingData, testData = transformed_sdf.randomSplit([0.7, 0.3], seed=42)

# Create a LogisticRegression Estimator
lr = LogisticRegression(featuresCol="features", labelCol="label")

# Fit the model to the training data
model = lr.fit(trainingData)

# Show model coefficients and intercept
print("Coefficients: ", model.coefficients)
print("Intercept: ", model.intercept)

# Test the model on the testData
test_results = model.transform(testData)

# Show the test results
test_results.select('Airline', 'Origin', 'CRSDepTime', 'DepTime', 'DepDelay', 'DepDelayMinutes', 'ArrTime',
                    'ArrDelay', 'Year', 'Quarter', 'Month', 'DayofMonth', 'DayOfWeek', 'CRSArrTime',
                    'ArrDelayMinutes', 'label', 'prediction').show(30, truncate=False)

# Show the confusion matrix
confusion_matrix = test_results.groupby('label').pivot('prediction').count().fillna(0).collect()
print("Confusion Matrix:")
for row in confusion_matrix:
    print(row)

# Define a function to calculate recall, precision, accuracy, and F1 score
def calculate_metrics(confusion_matrix):
    tn = confusion_matrix[0][1]  # True Negative
    fp = confusion_matrix[0][2]  # False Positive
    fn = confusion_matrix[1][1]  # False Negative
    tp = confusion_matrix[1][2]  # True Positive
    precision = tp / (tp + fp) if (tp + fp) != 0 else 0
    recall = tp / (tp + fn) if (tp + fn) != 0 else 0
    accuracy = (tp + tn) / (tp + tn + fp + fn)
    f1_score = 2 * (precision * recall) / (precision + recall) if (precision + recall) != 0 else 0
    return accuracy, precision, recall, f1_score

# Calculate metrics
accuracy, precision, recall, f1_score = calculate_metrics(confusion_matrix)
print("Accuracy:", accuracy)
print("Precision:", precision)
print("Recall:", recall)
print("F1 Score:", f1_score)


# Create a label
sdf = sdf.withColumn("label", when(sdf.ArrDelay > 0, 1.0).otherwise(0.0))

# Split the data into training and test sets
trainingData, testData = sdf.randomSplit([0.70, 0.3], seed=42)

# Create indexer
indexer = StringIndexer(inputCols=["Airline", "Origin"], outputCols=["AirlineIndex", "OriginIndex"], handleInvalid="keep")

# Create encoder
encoder = OneHotEncoder(inputCols=["AirlineIndex", "OriginIndex", "Quarter", "Month", "DayOfWeek"],
                        outputCols=["AirlineVector", "OriginVector", "QuarterVector", "MonthVector", "DayOfWeekVector"], dropLast=True, handleInvalid="keep")

# Create assembler
assembler = VectorAssembler(inputCols=['AirlineVector', 'OriginVector', 'QuarterVector', 'MonthVector', 'DayOfWeekVector', 'CRSDepTime', 'DepTime', 'DepDelay', 'DepDelayMinutes', 'ArrTime', 'ArrDelay', 'CRSArrTime', 'ArrDelayMinutes'], outputCol="features")

# Create a LogisticRegression Estimator
lr = LogisticRegression(maxIter=5)

# Create the pipeline
flights_pipe = Pipeline(stages=[indexer, encoder, assembler, lr])

# Create a grid to hold hyperparameters
grid = ParamGridBuilder()
grid = grid.addGrid(lr.regParam, [0.0, 0.2, 0.4, 0.6, 0.8, 1.0])
grid = grid.addGrid(lr.elasticNetParam, [0, 0.5, 1])

# Build the parameter grid
grid = grid.build()

# Number of models tested
print('Number of models to be tested: ', len(grid))

# BinaryClassificationEvaluator
evaluator = BinaryClassificationEvaluator(metricName="areaUnderROC")

# CrossValidator
cv = CrossValidator(estimator=flights_pipe,
                    estimatorParamMaps=grid,
                    evaluator=evaluator,
                    numFolds=3)

# Train the models
cv_model = cv.fit(trainingData)

# Test the predictions
predictions = cv_model.transform(testData)

# Calculate AUC
auc = evaluator.evaluate(predictions)
print(f"AUC: {auc}")

# Create the confusion matrix
predictions.groupby('label').pivot('prediction').count().fillna(0).show()
cm = predictions.groupby('label').pivot('prediction').count().fillna(0).collect































