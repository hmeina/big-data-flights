# Create directory for Kaggle
mkdir .kaggle
# Move json file with token from Kaggle website to .kaggle directory
mv kaggle.json .kaggle/
# Change and secure file permissions
chmod 600 .kaggle/kaggle.json
# Install needed packages
sudo apt -y install python3-pip python3.11-venv
sudo apt -y install zip
# Create python env
python3 -m venv pythondev
# Change to the just created directory
cd pythondev
# Activate env
source bin/activate
# Install Kaggle
pip3 install kaggle
# Download file from Kaggle
kaggle datasets download -d robikscube/flight-delay-dataset-20182022
# Unzip the zip file
unzip flight-delay-dataset-20182022.zip
# Create the bucket
gcloud storage buckets create gs://your-project-bucket-name --project=your-project-id --default-storage-class=STANDARD --location=us-central1 --uniform-bucket-level-access
# Authorize VM (if not already authorized)
gcloud auth login
# Save files to landing on the project bucket
gcloud storage cp *.csv gs://your-project-bucket-name/landing/








